Format: 3.0 (native)
Source: mysyspilot
Binary: mysyspilot
Architecture: all
Version: 1.4.1
Maintainer: Gus Salazar <gus.salazar66@gmail.com>
Standards-Version: 4.6.2
Build-Depends: debhelper-compat (= 13), python3:any
Package-List:
 mysyspilot deb utils optional arch=all
Checksums-Sha1:
 870f76fb236f28e310b7f8f39a3477c7e8ccdf70 137960 mysyspilot_1.4.1.tar.xz
Checksums-Sha256:
 d802a8b75a8598bcc253dfe5065952b3c396dbe2177f875b6589c80144731611 137960 mysyspilot_1.4.1.tar.xz
Files:
 cfc49a67103996cc7ca3399c7e7666e1 137960 mysyspilot_1.4.1.tar.xz
